#include "SettingsRootListController.h"

@implementation SettingsRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"Root" target:self] retain];
	}

	return _specifiers;
}




-(void)me
{
     
UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Fiori" message:@"This Tweak is completely with iOS11,12 and free , isn't allowed to sell and loot developer rights." preferredStyle:UIAlertControllerStyleAlert];
                          UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleCancel handler:nil];
                          [alertController addAction:alertAction];
                          [self presentViewController:alertController animated:YES completion:nil];
}





-(void)re {
    pid_t pid;
    const char* args[] = {"killall", "backboardd", NULL};
    posix_spawn(&pid, "/usr/bin/killall", NULL, NULL, (char* const*)args, NULL);
}




- (void)in {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"Instagram://user?screen_name=itsfioriii"]]) {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"Instagram://user?screen_name=itsfioriii"]];
    } else {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.instagram.com/itsfioriii/"]];
    }
}





- (void)tw {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"Twitter://user?screen_name=itsFiori"]]) {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"Twitter://user?screen_name=itsFiori"]];
    } else {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://twitter.com/itsFiori"]];
    }
}









- (void)pa {
   [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.paypal.me/AhmedSalahStore"] options:@{} completionHandler:nil];
}







- (void)so {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"#"] options:@{} completionHandler:nil];
}








@end
